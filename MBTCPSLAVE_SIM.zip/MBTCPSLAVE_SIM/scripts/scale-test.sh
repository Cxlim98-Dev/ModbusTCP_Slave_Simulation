#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_PATH="${PROJECT_DIR}/config/slaves.json"
PYTHON="${PROJECT_DIR}/.venv/bin/python"

if [[ ! -x "${PYTHON}" ]]; then
  echo "Python virtual environment not found. Run scripts/pi-bootstrap.sh first." >&2
  exit 1
fi

echo "== Modbus simulator scale check =="
prefix="$("${PYTHON}" - <<'PY'
from simulator.config import SimulatorConfig

config = SimulatorConfig.from_file("config/slaves.json")
print(f"configured={len(config.slaves)} enabled={len(config.enabled_slaves)} cidr=/{config.cidr_prefix} port={config.tcp_port}")
print(config.name_prefix)
PY
)"
summary="$(printf '%s\n' "${prefix}" | sed -n '1p')"
name_prefix="$(printf '%s\n' "${prefix}" | sed -n '2p')"
echo "${summary}"

echo
echo "Interfaces:"
ip -brief addr show | awk -v prefix="${name_prefix}" '$1 ~ "^" prefix { print }'

echo
echo "Interface count:"
ip -brief addr show | awk -v prefix="${name_prefix}" '$1 ~ "^" prefix { count++ } END { print count + 0 }'

echo
echo "Listening Modbus sockets:"
ss -ltnp | grep ':502' || true

echo
echo "Process summary:"
ps -eo pid,pcpu,pmem,comm,args | grep 'simulator.modbus_server' | grep -v grep || true
