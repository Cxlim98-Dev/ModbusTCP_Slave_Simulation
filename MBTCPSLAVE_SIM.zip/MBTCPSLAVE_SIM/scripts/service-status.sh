#!/usr/bin/env bash
set -euo pipefail

echo "== systemd services =="
for service in modbus-sim-web.service modbus-slave-simulator.service; do
  active="$(systemctl is-active "${service}" 2>/dev/null || true)"
  enabled="$(systemctl is-enabled "${service}" 2>/dev/null || true)"
  printf "%-32s active=%-12s enabled=%s\n" "${service}" "${active:-unknown}" "${enabled:-unknown}"
done

echo
echo "== simulator status =="
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
"${PROJECT_DIR}/.venv/bin/python" -m simulator.manage status

