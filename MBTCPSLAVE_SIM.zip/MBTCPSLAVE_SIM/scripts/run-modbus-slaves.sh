#!/usr/bin/env bash
set -euo pipefail

COUNT="${1:-${SLAVE_COUNT:-2}}"
BASE_IP_PREFIX="${BASE_IP_PREFIX:-185.180.180}"
START_HOST="${START_HOST:-101}"
PORT="${PORT:-502}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV_PYTHON="${PROJECT_DIR}/.venv/bin/python"
PID_DIR="${PROJECT_DIR}/run"

if ! [[ "${COUNT}" =~ ^[0-9]+$ ]] || (( COUNT < 1 || COUNT > 128 )); then
  echo "Slave count must be a number from 1 to 128." >&2
  exit 1
fi

if [[ ! -x "${VENV_PYTHON}" ]]; then
  echo "Python virtual environment not found at ${VENV_PYTHON}." >&2
  echo "Run: bash scripts/pi-bootstrap.sh" >&2
  exit 1
fi

mkdir -p "${PID_DIR}"

echo "== Start Modbus TCP slave servers =="

for i in $(seq 1 "${COUNT}"); do
  host="${BASE_IP_PREFIX}.$((START_HOST + i - 1))"
  pid_file="${PID_DIR}/modbus-slave-${i}.pid"
  log_file="${PID_DIR}/modbus-slave-${i}.log"

  if [[ -f "${pid_file}" ]] && kill -0 "$(cat "${pid_file}")" >/dev/null 2>&1; then
    echo "Slave ${i} already running with PID $(cat "${pid_file}")"
    continue
  fi

  echo "Starting slave ${i} on ${host}:${PORT}..."
  sudo "${VENV_PYTHON}" -m simulator.modbus_server \
    --host "${host}" \
    --port "${PORT}" \
    --slave-index "${i}" \
    >"${log_file}" 2>&1 &
  echo "$!" >"${pid_file}"
done

echo
echo "Listening sockets:"
ss -ltnp | grep ":${PORT}" || true

