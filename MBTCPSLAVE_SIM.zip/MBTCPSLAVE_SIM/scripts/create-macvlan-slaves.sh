#!/usr/bin/env bash
set -euo pipefail

PARENT_IFACE="${PARENT_IFACE:-eth0}"
COUNT="${1:-${SLAVE_COUNT:-2}}"
BASE_IP_PREFIX="${BASE_IP_PREFIX:-185.180.180}"
START_HOST="${START_HOST:-101}"
CIDR_PREFIX="${CIDR_PREFIX:-24}"
MAC_PREFIX="${MAC_PREFIX:-02:54:4d:33:00}"
NAME_PREFIX="${NAME_PREFIX:-mbslave}"

if ! [[ "${COUNT}" =~ ^[0-9]+$ ]] || (( COUNT < 1 || COUNT > 128 )); then
  echo "Slave count must be a number from 1 to 128." >&2
  exit 1
fi

if ! ip link show "${PARENT_IFACE}" >/dev/null 2>&1; then
  echo "Parent interface ${PARENT_IFACE} was not found." >&2
  exit 1
fi

echo "== Create Modbus macvlan slave interfaces =="
echo "Parent: ${PARENT_IFACE}"
echo "Count:  ${COUNT}"

for i in $(seq 1 "${COUNT}"); do
  host_octet=$((START_HOST + i - 1))
  if (( host_octet > 254 )); then
    echo "IP host octet exceeded 254 at slave ${i}." >&2
    exit 1
  fi

  iface="${NAME_PREFIX}${i}"
  ip_addr="${BASE_IP_PREFIX}.${host_octet}/${CIDR_PREFIX}"
  mac_addr="${MAC_PREFIX}:$(printf '%02x' "${i}")"

  if ip link show "${iface}" >/dev/null 2>&1; then
    echo "Updating existing ${iface}..."
    sudo ip link set "${iface}" down || true
    sudo ip addr flush dev "${iface}" || true
    sudo ip link set dev "${iface}" address "${mac_addr}"
  else
    echo "Creating ${iface}..."
    sudo ip link add "${iface}" link "${PARENT_IFACE}" address "${mac_addr}" type macvlan mode bridge
  fi

  sudo ip addr add "${ip_addr}" dev "${iface}"
  sudo ip link set "${iface}" up

  echo "  ${iface}: ${ip_addr} ${mac_addr}"
done

echo
echo "Created interfaces:"
ip -brief addr show | awk -v prefix="${NAME_PREFIX}" '$1 ~ "^" prefix { print }'

