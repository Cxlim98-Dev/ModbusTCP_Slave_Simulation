#!/usr/bin/env bash
set -euo pipefail

echo "== Raspberry Pi Modbus Simulator Preflight =="

echo
echo "OS:"
if [[ -r /etc/os-release ]]; then
  . /etc/os-release
  echo "  ${PRETTY_NAME:-unknown}"
else
  echo "  /etc/os-release not found"
fi

echo
echo "Kernel:"
uname -a

echo
echo "Architecture:"
uname -m

echo
echo "NetworkManager:"
if command -v nmcli >/dev/null 2>&1; then
  nmcli --version
  systemctl is-active NetworkManager || true
else
  echo "  nmcli not installed"
fi

echo
echo "Network devices:"
ip -brief link

echo
echo "IP addresses:"
ip -brief addr

echo
echo "Python:"
python3 --version

echo
echo "Listening TCP ports:"
ss -ltnp || true

echo
echo "Preflight complete."

