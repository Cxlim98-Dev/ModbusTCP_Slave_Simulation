#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV_DIR="${PROJECT_DIR}/.venv"

echo "== Raspberry Pi Modbus Simulator Bootstrap =="

echo
echo "Installing system packages..."
sudo apt update
sudo apt install -y \
  git curl ca-certificates jq htop \
  python3 python3-venv python3-pip \
  iproute2 net-tools

echo
echo "Creating Python virtual environment..."
python3 -m venv "${VENV_DIR}"

echo
echo "Upgrading Python packaging tools..."
"${VENV_DIR}/bin/python" -m pip install --upgrade pip setuptools wheel

if [[ -f "${PROJECT_DIR}/requirements.txt" ]]; then
  echo
  echo "Installing Python requirements..."
  "${VENV_DIR}/bin/python" -m pip install -r "${PROJECT_DIR}/requirements.txt"
fi

echo
echo "Bootstrap complete."
echo "Virtual environment: ${VENV_DIR}"
