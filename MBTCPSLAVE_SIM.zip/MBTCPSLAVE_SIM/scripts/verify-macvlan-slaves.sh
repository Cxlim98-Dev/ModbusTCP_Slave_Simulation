#!/usr/bin/env bash
set -euo pipefail

COUNT="${1:-${SLAVE_COUNT:-2}}"
BASE_IP_PREFIX="${BASE_IP_PREFIX:-185.180.180}"
START_HOST="${START_HOST:-101}"
MAC_PREFIX="${MAC_PREFIX:-02:54:4d:33:00}"
NAME_PREFIX="${NAME_PREFIX:-mbslave}"

if ! [[ "${COUNT}" =~ ^[0-9]+$ ]] || (( COUNT < 1 || COUNT > 128 )); then
  echo "Slave count must be a number from 1 to 128." >&2
  exit 1
fi

echo "== Verify Modbus macvlan slave interfaces =="

failed=0

for i in $(seq 1 "${COUNT}"); do
  iface="${NAME_PREFIX}${i}"
  ip_addr="${BASE_IP_PREFIX}.$((START_HOST + i - 1))"
  mac_addr="${MAC_PREFIX}:$(printf '%02x' "${i}")"

  if ! ip link show "${iface}" >/dev/null 2>&1; then
    echo "FAIL ${iface}: missing interface"
    failed=1
    continue
  fi

  actual_mac="$(cat "/sys/class/net/${iface}/address")"
  if [[ "${actual_mac}" != "${mac_addr}" ]]; then
    echo "FAIL ${iface}: MAC ${actual_mac}, expected ${mac_addr}"
    failed=1
    continue
  fi

  if ! ip -brief addr show "${iface}" | grep -q "${ip_addr}/"; then
    echo "FAIL ${iface}: missing IP ${ip_addr}"
    failed=1
    continue
  fi

  state="$(cat "/sys/class/net/${iface}/operstate")"
  echo "OK   ${iface}: ${ip_addr} ${mac_addr} state=${state}"
done

echo
ip -brief addr show | awk -v prefix="${NAME_PREFIX}" '$1 ~ "^" prefix { print }'

if (( failed != 0 )); then
  exit 1
fi

