#!/usr/bin/env bash
set -euo pipefail

COUNT="${1:-${SLAVE_COUNT:-128}}"
NAME_PREFIX="${NAME_PREFIX:-mbslave}"

if ! [[ "${COUNT}" =~ ^[0-9]+$ ]] || (( COUNT < 1 || COUNT > 128 )); then
  echo "Slave count must be a number from 1 to 128." >&2
  exit 1
fi

echo "== Delete Modbus macvlan slave interfaces =="

for i in $(seq 1 "${COUNT}"); do
  iface="${NAME_PREFIX}${i}"
  if ip link show "${iface}" >/dev/null 2>&1; then
    echo "Deleting ${iface}..."
    sudo ip link delete "${iface}"
  fi
done

echo "Done."

