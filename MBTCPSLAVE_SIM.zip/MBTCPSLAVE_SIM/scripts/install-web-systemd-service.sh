#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_PATH="/etc/systemd/system/modbus-sim-web.service"

if [[ ! -x "${PROJECT_DIR}/.venv/bin/python" ]]; then
  echo "Python virtual environment not found. Run scripts/pi-bootstrap.sh first." >&2
  exit 1
fi

sudo tee "${SERVICE_PATH}" >/dev/null <<SERVICE
[Unit]
Description=Raspberry Pi Modbus Simulator Web GUI
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${PROJECT_DIR}
ExecStart=${PROJECT_DIR}/.venv/bin/python -m simulator.web
Restart=on-failure
User=root
Group=root

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable modbus-sim-web.service

echo "Installed ${SERVICE_PATH}"
echo "Start now with:"
echo "  sudo systemctl start modbus-sim-web.service"
echo
echo "Open:"
echo "  http://modbus-sim.local:8080"

