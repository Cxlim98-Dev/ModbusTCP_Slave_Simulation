#!/usr/bin/env bash
set -euo pipefail

NAME_PREFIX="${NAME_PREFIX:-mbslave}"

echo "== Modbus macvlan slave interfaces =="

found=0
while read -r iface state addresses; do
  if [[ "${iface}" == "${NAME_PREFIX}"* ]]; then
    found=1
    mac="$(cat "/sys/class/net/${iface}/address")"
    printf "%-10s %-8s %-20s %s\n" "${iface}" "${state}" "${addresses:-no-ip}" "${mac}"
  fi
done < <(ip -brief addr show)

if (( found == 0 )); then
  echo "No ${NAME_PREFIX} interfaces found."
fi

