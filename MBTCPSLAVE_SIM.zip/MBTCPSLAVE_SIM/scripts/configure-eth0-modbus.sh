#!/usr/bin/env bash
set -euo pipefail

CONNECTION_NAME="${CONNECTION_NAME:-eth0-modbus}"
IFACE="${IFACE:-eth0}"
ETH0_ADDRESS="${ETH0_ADDRESS:-185.180.180.100/24}"

echo "== Configure ${IFACE} for Modbus simulator =="
echo "Connection: ${CONNECTION_NAME}"
echo "Address:    ${ETH0_ADDRESS}"

if ! command -v nmcli >/dev/null 2>&1; then
  echo "nmcli is required. Install NetworkManager first." >&2
  exit 1
fi

if ! ip link show "${IFACE}" >/dev/null 2>&1; then
  echo "Interface ${IFACE} was not found." >&2
  exit 1
fi

if nmcli -t -f NAME connection show | grep -Fxq "${CONNECTION_NAME}"; then
  echo "Updating existing connection ${CONNECTION_NAME}..."
else
  echo "Creating connection ${CONNECTION_NAME}..."
  sudo nmcli connection add type ethernet ifname "${IFACE}" con-name "${CONNECTION_NAME}"
fi

sudo nmcli connection modify "${CONNECTION_NAME}" \
  connection.interface-name "${IFACE}" \
  connection.autoconnect yes \
  ipv4.method manual \
  ipv4.addresses "${ETH0_ADDRESS}" \
  ipv4.gateway "" \
  ipv4.dns "" \
  ipv4.never-default yes \
  ipv6.method disabled

echo
echo "Bringing up ${CONNECTION_NAME}..."
sudo nmcli connection up "${CONNECTION_NAME}"

echo
echo "Current ${IFACE} address:"
ip -brief addr show "${IFACE}"

echo
echo "Route table:"
ip route

echo
echo "Done. ${IFACE} is configured for the Modbus simulator."
echo "Internet access should continue to use Wi-Fi or another default route."

