#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_PATH="/etc/systemd/system/modbus-slave-simulator.service"

if [[ ! -x "${PROJECT_DIR}/.venv/bin/python" ]]; then
  echo "Python virtual environment not found. Run scripts/pi-bootstrap.sh first." >&2
  exit 1
fi

sudo tee "${SERVICE_PATH}" >/dev/null <<SERVICE
[Unit]
Description=Raspberry Pi Modbus TCP Slave Simulator
After=network-online.target NetworkManager.service
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${PROJECT_DIR}
ExecStart=${PROJECT_DIR}/.venv/bin/python -m simulator.manage start
ExecStop=${PROJECT_DIR}/.venv/bin/python -m simulator.manage stop
User=root
Group=root

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable modbus-slave-simulator.service

echo "Installed ${SERVICE_PATH}"
echo "Start now with:"
echo "  sudo systemctl start modbus-slave-simulator.service"
echo
echo "View status with:"
echo "  systemctl status modbus-slave-simulator.service"
