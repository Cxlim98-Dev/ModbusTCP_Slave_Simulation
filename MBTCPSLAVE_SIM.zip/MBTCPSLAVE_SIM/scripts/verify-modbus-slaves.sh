#!/usr/bin/env bash
set -euo pipefail

COUNT="${1:-${SLAVE_COUNT:-2}}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV_PYTHON="${PROJECT_DIR}/.venv/bin/python"
CONFIG_PATH="${PROJECT_DIR}/config/slaves.json"

if [[ ! -x "${VENV_PYTHON}" ]]; then
  echo "Python virtual environment not found at ${VENV_PYTHON}." >&2
  echo "Run: bash scripts/pi-bootstrap.sh" >&2
  exit 1
fi

if [[ $# -gt 0 ]]; then
  "${VENV_PYTHON}" -m simulator.modbus_verify --count "${COUNT}"
else
  "${VENV_PYTHON}" -m simulator.modbus_verify --config "${CONFIG_PATH}"
fi
