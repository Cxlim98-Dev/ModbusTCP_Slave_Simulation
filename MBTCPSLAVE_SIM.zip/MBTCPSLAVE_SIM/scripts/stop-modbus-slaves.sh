#!/usr/bin/env bash
set -euo pipefail

COUNT="${1:-${SLAVE_COUNT:-128}}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PID_DIR="${PROJECT_DIR}/run"

if ! [[ "${COUNT}" =~ ^[0-9]+$ ]] || (( COUNT < 1 || COUNT > 128 )); then
  echo "Slave count must be a number from 1 to 128." >&2
  exit 1
fi

echo "== Stop Modbus TCP slave servers =="

for i in $(seq 1 "${COUNT}"); do
  pid_file="${PID_DIR}/modbus-slave-${i}.pid"
  if [[ ! -f "${pid_file}" ]]; then
    continue
  fi

  pid="$(cat "${pid_file}")"
  if kill -0 "${pid}" >/dev/null 2>&1; then
    echo "Stopping slave ${i} PID ${pid}..."
    sudo kill "${pid}"
  fi
  rm -f "${pid_file}"
done

echo "Done."

