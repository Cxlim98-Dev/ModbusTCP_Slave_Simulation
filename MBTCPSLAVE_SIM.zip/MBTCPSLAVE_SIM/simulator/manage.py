#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from simulator.config import SimulatorConfig


PROJECT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_DIR / "config" / "slaves.json"
RUN_DIR = PROJECT_DIR / "run"
PYTHON = PROJECT_DIR / ".venv" / "bin" / "python"


def run(command: list[str], *, check: bool = True, capture: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, check=check, text=True, capture_output=capture)


def require_root_for_network() -> None:
    if os.geteuid() != 0:
        raise SystemExit("This command must run with sudo because it creates network interfaces and binds port 502.")


def interface_exists(name: str) -> bool:
    return run(["ip", "link", "show", name], check=False).returncode == 0


def create_interfaces(config: SimulatorConfig) -> None:
    if not interface_exists(config.parent_interface):
        raise SystemExit(f"Parent interface {config.parent_interface} was not found.")

    for slave in config.enabled_slaves:
        iface = config.slave_iface(slave.index)
        mac = slave.mac_address
        cidr = f"{slave.ip_address}/{config.cidr_prefix}"

        if interface_exists(iface):
            print(f"Updating {iface} {cidr} {mac}")
            run(["ip", "link", "set", iface, "down"], check=False)
            run(["ip", "addr", "flush", "dev", iface], check=False)
            run(["ip", "link", "set", "dev", iface, "address", mac])
        else:
            print(f"Creating {iface} {cidr} {mac}")
            run([
                "ip",
                "link",
                "add",
                iface,
                "link",
                config.parent_interface,
                "address",
                mac,
                "type",
                "macvlan",
                "mode",
                "bridge",
            ])

        run(["ip", "addr", "add", cidr, "dev", iface])
        run(["ip", "link", "set", iface, "up"])


def delete_interfaces(config: SimulatorConfig, max_count: int | None = None) -> None:
    count = max_count or config.slave_count
    for index in range(1, count + 1):
        iface = f"{config.name_prefix}{index}"
        if interface_exists(iface):
            print(f"Deleting {iface}")
            run(["ip", "link", "delete", iface])


def start_servers(config: SimulatorConfig) -> None:
    RUN_DIR.mkdir(exist_ok=True)
    if not PYTHON.exists():
        raise SystemExit(f"Python virtual environment not found at {PYTHON}. Run scripts/pi-bootstrap.sh first.")

    for index in range(1, config.slave_count + 1):
        pid_file = RUN_DIR / f"modbus-slave-{index}.pid"
        log_file = RUN_DIR / f"modbus-slave-{index}.log"
        if pid_file.exists() and process_running(int(pid_file.read_text().strip())):
            print(f"Slave {index} already running with PID {pid_file.read_text().strip()}")
            continue

        slave = config.slave(index)
        if not slave.enabled:
            continue
        host = slave.ip_address
        command = [
            str(PYTHON),
            "-m",
            "simulator.modbus_server",
            "--host",
            host,
            "--port",
            str(config.tcp_port),
            "--slave-index",
            str(slave.index),
            "--profile",
            slave.profile,
            "--name",
            slave.name,
            "--tm3-modules",
            ",".join(slave.tm3_modules),
            "--value-file",
            str(RUN_DIR / f"slave-{slave.index}-values.json"),
        ]
        print(f"Starting slave {index} on {host}:{config.tcp_port}")
        with log_file.open("ab") as log:
            process = subprocess.Popen(command, cwd=PROJECT_DIR, stdout=log, stderr=log)
        pid_file.write_text(str(process.pid), encoding="utf-8")


def stop_servers(config: SimulatorConfig, max_count: int | None = None) -> None:
    count = max_count or config.slave_count
    for index in range(1, count + 1):
        pid_file = RUN_DIR / f"modbus-slave-{index}.pid"
        if not pid_file.exists():
            continue
        pid = int(pid_file.read_text().strip())
        if process_running(pid):
            print(f"Stopping slave {index} PID {pid}")
            os.kill(pid, signal.SIGTERM)
            wait_for_exit(pid)
        pid_file.unlink(missing_ok=True)


def process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def wait_for_exit(pid: int, timeout: float = 5.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not process_running(pid):
            return
        time.sleep(0.1)
    os.kill(pid, signal.SIGKILL)


def status(config: SimulatorConfig) -> None:
    print(f"Profile: {config.profile}")
    print(f"Slaves:  {len(config.enabled_slaves)} enabled / {len(config.slaves)} configured")
    for slave in config.slaves:
        iface = config.slave_iface(slave.index)
        ip_addr = slave.ip_address
        mac = slave.mac_address
        pid_file = RUN_DIR / f"modbus-slave-{slave.index}.pid"
        pid_status = "stopped"
        if pid_file.exists():
            pid = int(pid_file.read_text().strip())
            pid_status = f"running pid={pid}" if process_running(pid) else "stale pid"
        iface_status = "up" if interface_exists(iface) else "missing"
        port_status = "listening" if tcp_listening(ip_addr, config.tcp_port) else "closed"
        enabled = "enabled" if slave.enabled else "disabled"
        print(
            f"{iface:10s} {ip_addr:15s} {mac:17s} {slave.profile:20s} "
            f"{enabled:8s} iface={iface_status:7s} port={port_status:9s} server={pid_status}"
        )


def tcp_listening(host: str, port: int) -> bool:
    result = run(["ss", "-ltn"], check=False, capture=True)
    needle = f"{host}:{port}"
    return needle in result.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description="Manage the Modbus TCP slave simulator.")
    parser.add_argument("command", choices=["start", "stop", "restart", "status", "interfaces-up", "interfaces-down"])
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    args = parser.parse_args()

    config = SimulatorConfig.from_file(args.config)

    if args.command in {"start", "restart", "interfaces-up", "interfaces-down"}:
        require_root_for_network()

    if args.command == "start":
        create_interfaces(config)
        start_servers(config)
    elif args.command == "stop":
        stop_servers(config, max_count=128)
    elif args.command == "restart":
        stop_servers(config, max_count=128)
        delete_interfaces(config, max_count=128)
        create_interfaces(config)
        start_servers(config)
    elif args.command == "status":
        status(config)
    elif args.command == "interfaces-up":
        create_interfaces(config)
    elif args.command == "interfaces-down":
        delete_interfaces(config, max_count=128)

    return 0


if __name__ == "__main__":
    sys.exit(main())
