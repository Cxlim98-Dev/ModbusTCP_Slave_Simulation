#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from flask import Flask, Response, redirect, render_template_string, request, url_for

from simulator.config import SimulatorConfig, SUPPORTED_PROFILES, SlaveConfig
from simulator.live_values import default_values, ensure_value_file, load_values, save_values


PROJECT_DIR = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_DIR / "config" / "slaves.json"
RUN_DIR = PROJECT_DIR / "run"

app = Flask(__name__)


PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Modbus Slave Simulator</title>
  <style>
    :root {
      color-scheme: light;
      font-family: Arial, sans-serif;
      background: #f5f7f9;
      color: #16202a;
    }
    body { margin: 0; }
    header {
      background: #12343b;
      color: white;
      padding: 18px 24px;
    }
    main {
      max-width: 980px;
      margin: 0 auto;
      padding: 24px;
    }
    h1 { margin: 0; font-size: 24px; }
    h2 { margin-top: 0; font-size: 18px; }
    section {
      background: white;
      border: 1px solid #d9e1e7;
      border-radius: 8px;
      padding: 18px;
      margin-bottom: 18px;
    }
    label {
      display: block;
      font-weight: 700;
      margin-bottom: 6px;
    }
    input, select {
      box-sizing: border-box;
      width: 100%;
      border: 1px solid #b7c3cc;
      border-radius: 6px;
      padding: 9px 10px;
      font-size: 15px;
    }
    input[type="checkbox"] {
      width: auto;
      transform: scale(1.2);
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 18px;
    }
    button, .button {
      border: 0;
      border-radius: 6px;
      padding: 10px 14px;
      background: #116466;
      color: white;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
    }
    button.secondary, .button.secondary { background: #425563; }
    button.danger, .button.danger { background: #9f2d20; }
    button.apply { background: #0b6bcb; }
    table {
      border-collapse: collapse;
      width: 100%;
      font-size: 14px;
    }
    th, td {
      border-bottom: 1px solid #e1e7eb;
      padding: 9px;
      text-align: left;
    }
    th { background: #eef3f5; }
    td input, td select { min-width: 120px; }
    td:first-child input { min-width: 0; }
    pre {
      overflow: auto;
      background: #101820;
      color: #e7edf2;
      border-radius: 8px;
      padding: 14px;
      min-height: 60px;
    }
    .notice {
      background: #eaf7f1;
      border-color: #b9dfcf;
    }
    .service-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 12px;
    }
    .service {
      border: 1px solid #d9e1e7;
      border-radius: 8px;
      padding: 12px;
      background: #fbfcfd;
    }
    .service strong { display: block; margin-bottom: 4px; }
    @media (max-width: 720px) {
      .grid { grid-template-columns: 1fr; }
      .service-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <header>
    <h1>Modbus Slave Simulator</h1>
  </header>
  <main>
    {% if message %}
    <section class="notice">{{ message }}</section>
    {% endif %}

    <section>
      <h2>Configuration</h2>
      <form id="config-form" method="post" action="{{ url_for('save') }}">
        <div class="grid">
          <div>
            <label for="slave_count">Slave count</label>
            <input id="slave_count" name="slave_count" type="number" min="1" max="128" value="{{ config.slave_count }}" required>
          </div>
          <div>
            <label for="profile">Profile</label>
            <select id="profile" name="profile">
              {% for profile in profiles %}
              <option value="{{ profile }}" {% if profile == config.profile %}selected{% endif %}>{{ profile }}</option>
              {% endfor %}
            </select>
          </div>
          <div>
            <label for="parent_interface">Parent interface</label>
            <input id="parent_interface" name="parent_interface" value="{{ config.parent_interface }}" required>
          </div>
          <div>
            <label for="tcp_port">TCP port</label>
            <input id="tcp_port" name="tcp_port" type="number" min="1" max="65535" value="{{ config.tcp_port }}" required>
          </div>
          <div>
            <label for="base_ip_prefix">Base IP prefix</label>
            <input id="base_ip_prefix" name="base_ip_prefix" value="{{ config.base_ip_prefix }}" required>
          </div>
          <div>
            <label for="start_host">Start host octet</label>
            <input id="start_host" name="start_host" type="number" min="1" max="254" value="{{ config.start_host }}" required>
          </div>
          <div>
            <label for="cidr_prefix">CIDR prefix</label>
            <input id="cidr_prefix" name="cidr_prefix" type="number" min="1" max="32" value="{{ config.cidr_prefix }}" required>
          </div>
          <div>
            <label for="mac_prefix">MAC prefix</label>
            <input id="mac_prefix" name="mac_prefix" value="{{ config.mac_prefix }}" required>
          </div>
        </div>
        <div class="actions">
          <button type="submit">Save</button>
        </div>
      </form>
    </section>

    <section>
      <h2>Slaves</h2>
      <table>
        <thead><tr><th>On</th><th>#</th><th>Name</th><th>Interface</th><th>IP</th><th>MAC</th><th>Profile</th><th>TM3 Modules</th><th>Values</th></tr></thead>
        <tbody>
          {% for slave in slaves %}
          <tr>
            <td><input form="config-form" type="checkbox" name="slave_enabled_{{ slave.index }}" value="1" {% if slave.enabled %}checked{% endif %}></td>
            <td>{{ slave.index }}</td>
            <td><input form="config-form" name="slave_name_{{ slave.index }}" value="{{ slave.name }}"></td>
            <td>{{ slave.iface }}</td>
            <td><input form="config-form" name="slave_ip_{{ slave.index }}" value="{{ slave.ip }}"></td>
            <td><input form="config-form" name="slave_mac_{{ slave.index }}" value="{{ slave.mac }}"></td>
            <td>
              <select form="config-form" name="slave_profile_{{ slave.index }}" class="profile-select" data-index="{{ slave.index }}">
                {% for profile in profiles %}
                <option value="{{ profile }}" {% if profile == slave.profile %}selected{% endif %}>{{ profile }}</option>
                {% endfor %}
              </select>
            </td>
            <td><input form="config-form" class="tm3-modules" data-index="{{ slave.index }}" name="slave_tm3_modules_{{ slave.index }}" value="{{ slave.tm3_modules }}" {% if slave.profile != "schneider-tm3bceip" %}disabled{% endif %}></td>
            <td><a class="button secondary" href="{{ url_for('values', index=slave.index) }}">Values</a></td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </section>

    <section>
      <h2>Config Backup</h2>
      <div class="actions">
        <a class="button secondary" href="{{ url_for('export_config') }}">Export Config</a>
        <form method="post" action="{{ url_for('import_config') }}" enctype="multipart/form-data">
          <input type="file" name="config_file" accept="application/json,.json" required>
          <button class="secondary" type="submit">Import Config</button>
        </form>
      </div>
    </section>

    <section>
      <h2>Controls</h2>
      <form class="actions" method="post" action="{{ url_for('action') }}">
        <button name="command" value="start">Start</button>
        <button class="apply" name="command" value="restart">Apply & Restart Simulator</button>
        <button class="danger" name="command" value="stop">Stop</button>
        <button class="secondary" name="command" value="status">Refresh Status</button>
      </form>
      <div class="service-grid">
        {% for service in services %}
        <div class="service">
          <strong>{{ service.name }}</strong>
          <div>active: {{ service.active }}</div>
          <div>enabled: {{ service.enabled }}</div>
        </div>
        {% endfor %}
      </div>
      <pre>{{ status }}</pre>
    </section>
  </main>
  <script>
    function syncTm3ModuleFields() {
      document.querySelectorAll(".profile-select").forEach((select) => {
        const index = select.dataset.index;
        const input = document.querySelector(`.tm3-modules[data-index="${index}"]`);
        if (!input) return;
        const isTm3 = select.value === "schneider-tm3bceip";
        input.disabled = !isTm3;
        if (!isTm3) input.value = "";
      });
    }
    document.querySelectorAll(".profile-select").forEach((select) => {
      select.addEventListener("change", syncTm3ModuleFields);
    });
    syncTm3ModuleFields();
  </script>
</body>
</html>
"""


VALUES_PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Slave {{ slave.index }} Values</title>
  <style>
    :root { font-family: Arial, sans-serif; background: #f5f7f9; color: #16202a; }
    body { margin: 0; }
    header { background: #12343b; color: white; padding: 18px 24px; }
    main { max-width: 980px; margin: 0 auto; padding: 24px; }
    section { background: white; border: 1px solid #d9e1e7; border-radius: 8px; padding: 18px; margin-bottom: 18px; }
    h1 { margin: 0; font-size: 24px; }
    h2 { margin-top: 0; font-size: 18px; }
    table { border-collapse: collapse; width: 100%; font-size: 14px; }
    th, td { border-bottom: 1px solid #e1e7eb; padding: 8px; text-align: left; }
    th { background: #eef3f5; }
    input[type="number"] { width: 110px; padding: 7px; }
    button, .button { border: 0; border-radius: 6px; padding: 10px 14px; background: #116466; color: white; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-block; font-size: 14px; }
    .secondary { background: #425563; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 18px; }
    .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
    @media (max-width: 720px) { .grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <header><h1>{{ slave.name }} Values</h1></header>
  <main>
    <section>
      <div>IP: {{ slave.ip_address }}</div>
      <div>Profile: {{ slave.profile }}</div>
      <div>TM3 Modules: {{ slave.tm3_modules|join(",") }}</div>
      <div class="actions"><a class="button secondary" href="{{ url_for('index') }}">Back</a></div>
    </section>
    <form method="post" action="{{ url_for('save_values_route', index=slave.index) }}">
      <div class="grid">
        <section>
          <h2>Coils 0-15</h2>
          <table>
            <tbody>
              {% for i in range(16) %}
              <tr><td>{{ i }}</td><td><input type="checkbox" name="coils_{{ i }}" value="1" {% if values.coils[i] %}checked{% endif %}></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </section>
        <section>
          <h2>Discrete Inputs 0-15</h2>
          <table>
            <tbody>
              {% for i in range(16) %}
              <tr><td>{{ i }}</td><td><input type="checkbox" name="discrete_inputs_{{ i }}" value="1" {% if values.discrete_inputs[i] %}checked{% endif %}></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </section>
        <section>
          <h2>Holding Registers 0-20</h2>
          <table>
            <tbody>
              {% for i in range(21) %}
              <tr><td>{{ i }}</td><td><input type="number" min="0" max="65535" name="holding_registers_{{ i }}" value="{{ values.holding_registers[i] }}"></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </section>
        <section>
          <h2>Input Registers 0-20</h2>
          <table>
            <tbody>
              {% for i in range(21) %}
              <tr><td>{{ i }}</td><td><input type="number" min="0" max="65535" name="input_registers_{{ i }}" value="{{ values.input_registers[i] }}"></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </section>
      </div>
      <div class="actions">
        <button type="submit">Save Live Values</button>
        <a class="button secondary" href="{{ url_for('values', index=slave.index) }}">Refresh Values</a>
        <a class="button secondary" href="{{ url_for('reset_values', index=slave.index) }}">Reset Defaults</a>
      </div>
    </form>
  </main>
</body>
</html>
"""


def load_config() -> SimulatorConfig:
    return SimulatorConfig.from_file(CONFIG_PATH)


def config_to_dict(config: SimulatorConfig) -> dict[str, object]:
    return {
        "parent_interface": config.parent_interface,
        "base_ip_prefix": config.base_ip_prefix,
        "start_host": config.start_host,
        "cidr_prefix": config.cidr_prefix,
        "mac_prefix": config.mac_prefix,
        "name_prefix": config.name_prefix,
        "tcp_port": config.tcp_port,
        "slave_count": config.slave_count,
        "profile": config.profile,
        "slaves": [
            {
                "index": slave.index,
                "enabled": slave.enabled,
                "name": slave.name,
                "profile": slave.profile,
                "ip_address": slave.ip_address,
                "mac_address": slave.mac_address,
                "tm3_modules": list(slave.tm3_modules),
            }
            for slave in config.slaves
        ],
    }


def run_manage(command: str) -> str:
    prefix = ["sudo"] if command in {"start", "restart"} else []
    result = subprocess.run(
        [*prefix, str(PROJECT_DIR / ".venv" / "bin" / "python"), "-m", "simulator.manage", command],
        cwd=PROJECT_DIR,
        text=True,
        capture_output=True,
        check=False,
    )
    output = "\n".join(part for part in [result.stdout, result.stderr] if part)
    return output or f"{command} completed"


def service_state(service: str) -> dict[str, str]:
    active = subprocess.run(["systemctl", "is-active", service], text=True, capture_output=True, check=False)
    enabled = subprocess.run(["systemctl", "is-enabled", service], text=True, capture_output=True, check=False)
    return {
        "name": service,
        "active": active.stdout.strip() or "unknown",
        "enabled": enabled.stdout.strip() or "unknown",
    }


def service_states() -> list[dict[str, str]]:
    return [
        service_state("modbus-sim-web.service"),
        service_state("modbus-slave-simulator.service"),
    ]


def value_file(index: int) -> Path:
    return RUN_DIR / f"slave-{index}-values.json"


def slave_or_404(config: SimulatorConfig, index: int) -> SlaveConfig:
    for slave in config.slaves:
        if slave.index == index:
            return slave
    raise ValueError(f"Slave {index} is not configured")


@app.get("/")
def index():
    config = load_config()
    slaves = [
        {
            "index": slave.index,
            "enabled": slave.enabled,
            "name": slave.name,
            "profile": slave.profile,
            "iface": config.slave_iface(slave.index),
            "ip": slave.ip_address,
            "mac": slave.mac_address,
            "tm3_modules": ",".join(slave.tm3_modules),
        }
        for slave in config.slaves
    ]
    status = run_manage("status")
    return render_template_string(
        PAGE,
        config=config,
        profiles=sorted(SUPPORTED_PROFILES),
        slaves=slaves,
        status=status,
        services=service_states(),
        message=request.args.get("message", ""),
    )


@app.get("/values/<int:index>")
def values(index: int):
    config = load_config()
    try:
        slave = slave_or_404(config, index)
    except ValueError as exc:
        return redirect(url_for("index", message=str(exc)))
    path = value_file(index)
    ensure_value_file(path, slave.index, slave.profile, slave.ip_address, slave.tm3_modules)
    current_values = load_values(path)
    return render_template_string(VALUES_PAGE, slave=slave, values=current_values)


@app.post("/values/<int:index>")
def save_values_route(index: int):
    config = load_config()
    try:
        slave = slave_or_404(config, index)
    except ValueError as exc:
        return redirect(url_for("index", message=str(exc)))
    path = value_file(index)
    ensure_value_file(path, slave.index, slave.profile, slave.ip_address, slave.tm3_modules)
    current_values = load_values(path)

    for i in range(16):
        current_values["coils"][i] = f"coils_{i}" in request.form
        current_values["discrete_inputs"][i] = f"discrete_inputs_{i}" in request.form
    for value_type in ("holding_registers", "input_registers"):
        for i in range(21):
            raw = request.form.get(f"{value_type}_{i}", "0")
            current_values[value_type][i] = max(0, min(65535, int(raw or 0)))

    save_values(path, current_values)
    return redirect(url_for("values", index=index))


@app.get("/values/<int:index>/reset")
def reset_values(index: int):
    config = load_config()
    try:
        slave = slave_or_404(config, index)
    except ValueError as exc:
        return redirect(url_for("index", message=str(exc)))
    save_values(value_file(index), default_values(slave.index, slave.profile, slave.ip_address, slave.tm3_modules))
    return redirect(url_for("values", index=index))


@app.post("/save")
def save():
    current = load_config()
    data = config_to_dict(current)
    for key in [
        "parent_interface",
        "base_ip_prefix",
        "start_host",
        "cidr_prefix",
        "mac_prefix",
        "tcp_port",
        "slave_count",
        "profile",
    ]:
        value = request.form[key]
        if key in {"start_host", "cidr_prefix", "tcp_port", "slave_count"}:
            data[key] = int(value)
        else:
            data[key] = value

    generated = SimulatorConfig._generated_slaves(data)
    slaves = []
    for index in range(1, int(data["slave_count"]) + 1):
        defaults = generated[index - 1]
        enabled = f"slave_enabled_{index}" in request.form
        if index > len(current.slaves):
            enabled = True
        profile = request.form.get(f"slave_profile_{index}") or str(data["profile"])
        tm3_modules = ()
        if profile == "schneider-tm3bceip":
            tm3_modules = parse_tm3_modules(request.form.get(f"slave_tm3_modules_{index}", ""))
        slaves.append(
            SlaveConfig(
                index=index,
                enabled=enabled,
                name=request.form.get(f"slave_name_{index}") or str(defaults["name"]),
                profile=profile,
                ip_address=request.form.get(f"slave_ip_{index}") or str(defaults["ip_address"]),
                mac_address=request.form.get(f"slave_mac_{index}") or str(defaults["mac_address"]),
                tm3_modules=tm3_modules,
            )
        )
    data["slaves"] = tuple(slaves)

    updated = SimulatorConfig(**data)
    updated.validate()
    CONFIG_PATH.write_text(json.dumps(config_to_dict(updated), indent=2) + "\n", encoding="utf-8")
    return redirect(url_for("index", message="Configuration saved. Restart the simulator to apply changes."))


@app.get("/config/export")
def export_config():
    config = load_config()
    payload = json.dumps(config_to_dict(config), indent=2) + "\n"
    return Response(
        payload,
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=slaves.json"},
    )


@app.post("/config/import")
def import_config():
    uploaded = request.files.get("config_file")
    if not uploaded:
        return redirect(url_for("index", message="No config file selected."))
    try:
        data = json.loads(uploaded.read().decode("utf-8"))
        generated = SimulatorConfig._generated_slaves(data)
        requested_count = int(data.get("slave_count", len(generated) or 2))
        raw_slaves = list(data.get("slaves") or generated)[:requested_count]
        if len(raw_slaves) < requested_count:
            raw_slaves.extend(generated[len(raw_slaves) : requested_count])
        slaves = []
        for offset, item in enumerate(raw_slaves, start=1):
            profile = item.get("profile") or data.get("profile", "generic-modbus-tcp")
            tm3_modules = ()
            if profile == "schneider-tm3bceip":
                tm3_modules = (
                    tuple(item["tm3_modules"])
                    if "tm3_modules" in item
                    else tuple(generated[offset - 1]["tm3_modules"])
                )
            slaves.append(
                SlaveConfig(
                    index=int(item.get("index", offset)),
                    enabled=bool(item.get("enabled", True)),
                    name=item.get("name") or f"Slave {offset}",
                    profile=profile,
                    ip_address=item.get("ip_address") or str(generated[offset - 1]["ip_address"]),
                    mac_address=item.get("mac_address") or str(generated[offset - 1]["mac_address"]),
                    tm3_modules=tm3_modules,
                )
            )
        imported = SimulatorConfig(
            parent_interface=data.get("parent_interface", "eth0"),
            base_ip_prefix=data.get("base_ip_prefix", "185.180.180"),
            start_host=int(data.get("start_host", 101)),
            cidr_prefix=int(data.get("cidr_prefix", 24)),
            mac_prefix=data.get("mac_prefix", "02:54:4d:33:00"),
            name_prefix=data.get("name_prefix", "mbslave"),
            tcp_port=int(data.get("tcp_port", 502)),
            slave_count=requested_count,
            profile=data.get("profile", "generic-modbus-tcp"),
            slaves=tuple(slaves),
        )
        imported.validate()
    except Exception as exc:
        return redirect(url_for("index", message=f"Import failed: {exc}"))

    CONFIG_PATH.write_text(json.dumps(config_to_dict(imported), indent=2) + "\n", encoding="utf-8")
    return redirect(url_for("index", message="Configuration imported. Apply & Restart Simulator to use it."))


def parse_tm3_modules(raw: str) -> tuple[str, ...]:
    modules = tuple(part.strip().upper() for part in raw.split(",") if part.strip())
    return modules


@app.post("/action")
def action():
    command = request.form["command"]
    if command == "status":
        return redirect(url_for("index"))
    output = run_manage(command)
    return redirect(url_for("index", message=output[-300:]))


def main() -> None:
    app.run(host="0.0.0.0", port=8080)


if __name__ == "__main__":
    main()
