from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from pymodbus.datastore import ModbusSequentialDataBlock


VALUE_SIZE = 10000
VALUE_TYPES = ("coils", "discrete_inputs", "holding_registers", "input_registers")


def default_values(slave_index: int, profile: str, host: str, tm3_modules: tuple[str, ...]) -> dict[str, list[Any]]:
    values: dict[str, list[Any]] = {
        "coils": [False] * VALUE_SIZE,
        "discrete_inputs": [False] * VALUE_SIZE,
        "holding_registers": [0] * VALUE_SIZE,
        "input_registers": [0] * VALUE_SIZE,
    }

    holding_registers = values["holding_registers"]
    input_registers = values["input_registers"]
    coils = values["coils"]
    discrete_inputs = values["discrete_inputs"]

    holding_registers[0] = slave_index
    for offset, octet in enumerate(host.split(".")[:4], start=1):
        holding_registers[offset] = int(octet)

    input_registers[0] = slave_index
    input_registers[1] = 1000 + slave_index

    if profile == "schneider-tm3bceip":
        holding_registers[900] = 0
        holding_registers[901] = slave_index
        holding_registers[902] = len(tm3_modules)
        holding_registers[930] = 1
        holding_registers[931] = 0
        holding_registers[932] = 5
        holding_registers[933] = 0
        holding_registers[934] = 0
        holding_registers[935] = 0
        input_registers[900] = 1
        input_registers[930] = 1

        module_codes = {
            "TM3DI16": 0x0316,
            "TM3DQ16": 0x0416,
            "TM3AI4": 0x0504,
            "TM3AQ4": 0x0604,
        }
        for slot, module in enumerate(tm3_modules, start=1):
            holding_registers[940 + slot - 1] = module_codes.get(module, 0)

        if "TM3DI16" in tm3_modules:
            for channel in range(16):
                discrete_inputs[channel] = False
        if "TM3DQ16" in tm3_modules:
            for channel in range(16):
                coils[channel] = False
        if "TM3AI4" in tm3_modules:
            for channel in range(4):
                input_registers[channel] = 1000 + slave_index * 10 + channel
        if "TM3AQ4" in tm3_modules:
            for channel in range(4):
                holding_registers[100 + channel] = 0

    return values


def ensure_value_file(
    path: Path,
    slave_index: int,
    profile: str,
    host: str,
    tm3_modules: tuple[str, ...],
) -> None:
    if path.exists():
        return
    save_values(path, default_values(slave_index, profile, host, tm3_modules))


def load_values(path: Path) -> dict[str, list[Any]]:
    if not path.exists():
        raise FileNotFoundError(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    values = {}
    for value_type in VALUE_TYPES:
        default = [False] * VALUE_SIZE if value_type in {"coils", "discrete_inputs"} else [0] * VALUE_SIZE
        incoming = list(data.get(value_type, []))
        values[value_type] = (incoming + default)[:VALUE_SIZE]
    return values


def save_values(path: Path, values: dict[str, list[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = {}
    for value_type in VALUE_TYPES:
        default = [False] * VALUE_SIZE if value_type in {"coils", "discrete_inputs"} else [0] * VALUE_SIZE
        normalized[value_type] = (list(values.get(value_type, [])) + default)[:VALUE_SIZE]
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(normalized, separators=(",", ":")) + "\n", encoding="utf-8")
    os.replace(tmp_path, path)


class FileBackedDataBlock(ModbusSequentialDataBlock):
    def __init__(self, path: Path, value_type: str):
        self.path = path
        self.value_type = value_type
        super().__init__(0, self._current_values())

    def _current_values(self) -> list[Any]:
        return load_values(self.path)[self.value_type]

    def getValues(self, address: int, count: int = 1) -> list[Any]:
        values = self._current_values()
        return values[address : address + count]

    def setValues(self, address: int, values: list[Any]) -> None:
        current = load_values(self.path)
        target = current[self.value_type]
        for offset, value in enumerate(values):
            if address + offset < len(target):
                target[address + offset] = bool(value) if self.value_type in {"coils", "discrete_inputs"} else int(value)
        save_values(self.path, current)

