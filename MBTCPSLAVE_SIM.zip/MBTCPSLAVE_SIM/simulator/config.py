from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


SUPPORTED_PROFILES = {"generic-modbus-tcp", "schneider-tm3bceip"}


@dataclass(frozen=True)
class SlaveConfig:
    index: int
    enabled: bool
    name: str
    profile: str
    ip_address: str
    mac_address: str
    tm3_modules: tuple[str, ...] = ("TM3DI16", "TM3DQ16", "TM3AI4", "TM3AQ4")

    def validate(self) -> None:
        if not 1 <= self.index <= 128:
            raise ValueError("slave index must be from 1 to 128")
        if self.profile not in SUPPORTED_PROFILES:
            raise ValueError(f"slave {self.index} profile must be one of: {', '.join(sorted(SUPPORTED_PROFILES))}")
        if not self.ip_address:
            raise ValueError(f"slave {self.index} requires an IP address")
        parts = self.mac_address.split(":")
        if len(parts) != 6 or any(len(part) != 2 for part in parts):
            raise ValueError(f"slave {self.index} MAC address must use aa:bb:cc:dd:ee:ff format")
        for module in self.tm3_modules:
            if module not in {"TM3DI16", "TM3DQ16", "TM3AI4", "TM3AQ4"}:
                raise ValueError(f"slave {self.index} unsupported TM3 module: {module}")
        if self.profile != "schneider-tm3bceip" and self.tm3_modules:
            raise ValueError(f"slave {self.index} TM3 modules can only be set when profile is schneider-tm3bceip")


@dataclass(frozen=True)
class SimulatorConfig:
    parent_interface: str
    base_ip_prefix: str
    start_host: int
    cidr_prefix: int
    mac_prefix: str
    name_prefix: str
    tcp_port: int
    slave_count: int
    profile: str
    slaves: tuple[SlaveConfig, ...]

    @classmethod
    def from_file(cls, path: str | Path) -> "SimulatorConfig":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        generated = cls._generated_slaves(data)
        requested_count = int(data.get("slave_count", len(generated) or 2))
        configured_slaves = list(data.get("slaves") or [])
        raw_slaves = configured_slaves[:requested_count]
        if len(raw_slaves) < requested_count:
            raw_slaves.extend(generated[len(raw_slaves) : requested_count])
        slaves = tuple(
            SlaveConfig(
                index=int(item.get("index", offset)),
                enabled=bool(item.get("enabled", True)),
                name=item.get("name") or f"Slave {offset}",
                profile=item.get("profile") or data.get("profile", "generic-modbus-tcp"),
                ip_address=item.get("ip_address") or generated[offset - 1]["ip_address"],
                mac_address=item.get("mac_address") or generated[offset - 1]["mac_address"],
                tm3_modules=tuple(item["tm3_modules"])
                if "tm3_modules" in item
                else tuple(generated[offset - 1]["tm3_modules"]),
            )
            for offset, item in enumerate(raw_slaves, start=1)
        )
        config = cls(
            parent_interface=data.get("parent_interface", "eth0"),
            base_ip_prefix=data.get("base_ip_prefix", "185.180.180"),
            start_host=int(data.get("start_host", 101)),
            cidr_prefix=int(data.get("cidr_prefix", 24)),
            mac_prefix=data.get("mac_prefix", "02:54:4d:33:00"),
            name_prefix=data.get("name_prefix", "mbslave"),
            tcp_port=int(data.get("tcp_port", 502)),
            slave_count=requested_count,
            profile=data.get("profile", "generic-modbus-tcp"),
            slaves=slaves,
        )
        config.validate()
        return config

    @staticmethod
    def _generated_slaves(data: dict[str, object]) -> list[dict[str, object]]:
        count = int(data.get("slave_count", 2))
        base_ip_prefix = str(data.get("base_ip_prefix", "185.180.180"))
        start_host = int(data.get("start_host", 101))
        mac_prefix = str(data.get("mac_prefix", "02:54:4d:33:00"))
        profile = str(data.get("profile", "generic-modbus-tcp"))
        return [
            {
                "index": index,
                "enabled": True,
                "name": f"Slave {index}",
                "profile": profile,
                "ip_address": f"{base_ip_prefix}.{start_host + index - 1}",
                "mac_address": f"{mac_prefix}:{index:02x}",
                "tm3_modules": ["TM3DI16", "TM3DQ16", "TM3AI4", "TM3AQ4"] if profile == "schneider-tm3bceip" else [],
            }
            for index in range(1, count + 1)
        ]

    def validate(self) -> None:
        if not 1 <= self.slave_count <= 128:
            raise ValueError("slave_count must be from 1 to 128")
        if not 1 <= self.start_host <= 254:
            raise ValueError("start_host must be from 1 to 254")
        if self.start_host + self.slave_count - 1 > 254:
            raise ValueError("configured slave IP range exceeds .254")
        if not 1 <= self.cidr_prefix <= 32:
            raise ValueError("cidr_prefix must be from 1 to 32")
        if not 1 <= self.tcp_port <= 65535:
            raise ValueError("tcp_port must be from 1 to 65535")
        if self.profile not in SUPPORTED_PROFILES:
            raise ValueError(f"profile must be one of: {', '.join(sorted(SUPPORTED_PROFILES))}")
        if len(self.slaves) > 128:
            raise ValueError("slaves list cannot contain more than 128 entries")
        seen_ips: set[str] = set()
        seen_macs: set[str] = set()
        for slave in self.slaves:
            slave.validate()
            if slave.enabled:
                if slave.ip_address in seen_ips:
                    raise ValueError(f"duplicate enabled slave IP address: {slave.ip_address}")
                if slave.mac_address.lower() in seen_macs:
                    raise ValueError(f"duplicate enabled slave MAC address: {slave.mac_address}")
                seen_ips.add(slave.ip_address)
                seen_macs.add(slave.mac_address.lower())

    @property
    def enabled_slaves(self) -> tuple[SlaveConfig, ...]:
        return tuple(slave for slave in self.slaves if slave.enabled)

    def slave_ip(self, index: int) -> str:
        return self.slave(index).ip_address

    def slave_cidr(self, index: int) -> str:
        return f"{self.slave_ip(index)}/{self.cidr_prefix}"

    def slave_mac(self, index: int) -> str:
        return self.slave(index).mac_address

    def slave_iface(self, index: int) -> str:
        self._validate_index(index)
        return f"{self.name_prefix}{index}"

    def slave(self, index: int) -> SlaveConfig:
        self._validate_index(index)
        for slave in self.slaves:
            if slave.index == index:
                return slave
        return SlaveConfig(
            index=index,
            enabled=True,
            name=f"Slave {index}",
            profile=self.profile,
            ip_address=f"{self.base_ip_prefix}.{self.start_host + index - 1}",
            mac_address=f"{self.mac_prefix}:{index:02x}",
            tm3_modules=("TM3DI16", "TM3DQ16", "TM3AI4", "TM3AQ4") if self.profile == "schneider-tm3bceip" else (),
        )

    def _validate_index(self, index: int) -> None:
        if not 1 <= index <= self.slave_count:
            raise ValueError(f"slave index must be from 1 to {self.slave_count}")
