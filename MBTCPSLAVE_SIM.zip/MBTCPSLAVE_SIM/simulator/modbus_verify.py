#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys

from pymodbus.client import ModbusTcpClient

from simulator.config import SimulatorConfig


def verify_slave(host: str, port: int, expected_index: int) -> bool:
    client = ModbusTcpClient(host=host, port=port, timeout=3)
    try:
        if not client.connect():
            print(f"FAIL {host}:{port}: could not connect")
            return False

        result = client.read_holding_registers(address=0, count=5)
        if result.isError():
            print(f"FAIL {host}:{port}: read error {result}")
            return False

        registers = result.registers
        if registers[0] != expected_index:
            print(f"FAIL {host}:{port}: register 0 = {registers[0]}, expected slave index {expected_index}")
            return False

        print(f"OK   {host}:{port}: holding registers 0-4 = {registers}")
        return True
    finally:
        client.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify simulated Modbus TCP slaves.")
    parser.add_argument("--base-ip-prefix", default="185.180.180")
    parser.add_argument("--start-host", type=int, default=101)
    parser.add_argument("--count", type=int)
    parser.add_argument("--port", type=int, default=502)
    parser.add_argument("--config")
    args = parser.parse_args()

    config = None
    if args.config:
        config = SimulatorConfig.from_file(args.config)
        args.base_ip_prefix = config.base_ip_prefix
        args.start_host = config.start_host
        args.count = config.slave_count
        args.port = config.tcp_port
    elif args.count is None:
        args.count = 2

    ok = True
    if config:
        for slave in config.enabled_slaves:
            ok = verify_slave(slave.ip_address, args.port, slave.index) and ok
    else:
        for index in range(1, args.count + 1):
            host = f"{args.base_ip_prefix}.{args.start_host + index - 1}"
            ok = verify_slave(host, args.port, index) and ok

    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
