#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import logging
from collections.abc import Sequence
from pathlib import Path

from pymodbus.device import ModbusDeviceIdentification
from pymodbus.datastore import ModbusServerContext, ModbusSlaveContext
from pymodbus.server import StartAsyncTcpServer

from simulator.live_values import FileBackedDataBlock, ensure_value_file


DEFAULT_TM3_MODULES = ("TM3DI16", "TM3DQ16", "TM3AI4", "TM3AQ4")


def build_context(
    slave_index: int,
    profile: str,
    host: str,
    tm3_modules: Sequence[str],
    value_file: Path,
) -> ModbusServerContext:
    ensure_value_file(value_file, slave_index, profile, host, tuple(tm3_modules))
    slave_context = ModbusSlaveContext(
        di=FileBackedDataBlock(value_file, "discrete_inputs"),
        co=FileBackedDataBlock(value_file, "coils"),
        hr=FileBackedDataBlock(value_file, "holding_registers"),
        ir=FileBackedDataBlock(value_file, "input_registers"),
    )

    return ModbusServerContext(slaves=slave_context, single=True)


def build_identity(profile: str, slave_index: int, name: str) -> ModbusDeviceIdentification:
    identity = ModbusDeviceIdentification()
    if profile == "schneider-tm3bceip":
        identity.VendorName = "Schneider Electric"
        identity.ProductCode = "TM3BCEIP"
        identity.VendorUrl = "https://www.se.com"
        identity.ProductName = "Modicon TM3 Ethernet Bus Coupler"
        identity.ModelName = "TM3BCEIP"
        identity.MajorMinorRevision = "1.0"
    else:
        identity.VendorName = "Raspberry Pi"
        identity.ProductCode = "RPI-MBTCP-SIM"
        identity.ProductName = "Modbus TCP Slave Simulator"
        identity.ModelName = name
        identity.MajorMinorRevision = "1.0"
    identity.UserApplicationName = f"{name} #{slave_index}"
    return identity


async def main() -> None:
    parser = argparse.ArgumentParser(description="Run one Modbus TCP slave server.")
    parser.add_argument("--host", required=True, help="IP address to bind, for example 185.180.180.101")
    parser.add_argument("--port", type=int, default=502, help="TCP port to bind")
    parser.add_argument("--slave-index", type=int, required=True, help="Slave index used for default register values")
    parser.add_argument("--profile", default="generic-modbus-tcp", choices=["generic-modbus-tcp", "schneider-tm3bceip"])
    parser.add_argument("--name", default="Modbus Slave")
    parser.add_argument("--tm3-modules", default=",".join(DEFAULT_TM3_MODULES))
    parser.add_argument("--value-file", required=True)
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s %(levelname)s %(message)s")
    logging.info(
        "Starting Modbus TCP slave %s on %s:%s profile=%s",
        args.slave_index,
        args.host,
        args.port,
        args.profile,
    )

    await StartAsyncTcpServer(
        context=build_context(
            args.slave_index,
            args.profile,
            args.host,
            parse_modules(args.tm3_modules),
            Path(args.value_file),
        ),
        identity=build_identity(args.profile, args.slave_index, args.name),
        address=(args.host, args.port),
    )


def parse_modules(raw: str) -> tuple[str, ...]:
    modules = tuple(part.strip().upper() for part in raw.split(",") if part.strip())
    return modules


if __name__ == "__main__":
    asyncio.run(main())
