# Raspberry Pi Setup

This guide prepares a fresh Raspberry Pi for the Modbus TCP slave simulator.

The target setup is:

- Raspberry Pi OS Lite 64-bit.
- Wired Ethernet preferred.
- One management IP for SSH and the web GUI.
- Later, up to 128 virtual Ethernet identities for Modbus TCP slaves.

## 0. Hardware And Network Assumptions

Use a Raspberry Pi 4 or Raspberry Pi 5 if possible. A Pi 3 can work for smaller tests, but 128 simulated slaves is better suited to a Pi 4/5.

Recommended:

- Raspberry Pi 4/5 with 2 GB RAM or more.
- 16 GB or larger microSD card.
- Wired Ethernet connected to the same test network as the Modbus TCP master.
- Raspberry Pi OS Lite 64-bit.

Important network note: each simulated slave will use a virtual interface with a unique MAC address and IP address. Some managed switches, routers, DHCP servers, and corporate networks block multiple MAC addresses behind one physical port. For reliable testing, use a dedicated lab switch or configure the network to allow this.

## 1. Flash Raspberry Pi OS

On your computer, install Raspberry Pi Imager:

- <https://www.raspberrypi.com/software/>

In Raspberry Pi Imager:

1. Choose your Raspberry Pi model.
2. Choose `Raspberry Pi OS Lite (64-bit)`.
3. Choose your microSD card.
4. Open OS customisation.
5. Set:
   - Hostname: `modbus-sim`
   - Username and password
   - SSH enabled
   - Locale, keyboard, and timezone
6. Write the card.

Insert the card into the Pi, connect Ethernet, then power it on.

## 2. First SSH Login

From your computer:

```sh
ssh <your-user>@modbus-sim.local
```

If `.local` name resolution does not work, find the Pi IP address from your router or with a network scanner, then:

```sh
ssh <your-user>@<pi-ip-address>
```

## 3. Update The Pi

Run:

```sh
sudo apt update
sudo apt full-upgrade -y
sudo reboot
```

Reconnect after reboot:

```sh
ssh <your-user>@modbus-sim.local
```

## 4. Install Base Packages

Run:

```sh
sudo apt install -y \
  git curl ca-certificates vim htop jq \
  python3 python3-venv python3-pip \
  network-manager
```

Check that NetworkManager is active:

```sh
systemctl is-active NetworkManager
nmcli device status
```

Recent Raspberry Pi OS releases use NetworkManager by default. That is what we will use for the management IP and later virtual slave interfaces.

## 5. Set A Static Management IP

Pick one stable IP address for the Raspberry Pi itself. This is the address you will use for SSH and the web GUI. Do not use this range for the simulated slave IPs.

Example values for this simulator lab network:

- Pi Ethernet Modbus IP: `185.180.180.100/24`
- Gateway: none
- DNS: none
- Ethernet interface: `eth0`

Find the active connection name:

```sh
nmcli connection show --active
```

Then configure it. Replace `Wired connection 1` and the IP values as needed:

```sh
sudo nmcli connection modify "Wired connection 1" \
  ipv4.method manual \
  ipv4.addresses 185.180.180.100/24 \
  ipv4.gateway "" \
  ipv4.dns "" \
  ipv4.never-default yes

sudo nmcli connection down "Wired connection 1"
sudo nmcli connection up "Wired connection 1"
```

If your SSH session drops, reconnect using the new IP:

```sh
ssh <your-user>@185.180.180.100
```

Verify:

```sh
ip addr show eth0
ip route
ip route
```

## 6. Enable Useful System Settings

Set hostname if you did not already do it in Raspberry Pi Imager:

```sh
sudo hostnamectl set-hostname modbus-sim
```

Enable SSH:

```sh
sudo systemctl enable --now ssh
```

Check OS and kernel:

```sh
cat /etc/os-release
uname -a
```

## 7. Prepare Project Directory

You have two options.

Option A is recommended: create a Git repository on GitHub, GitLab, Bitbucket, or your own Git server, then clone it on the Pi.

From this project on your Mac, initialise and push the repo:

```sh
git init
git add README.md docs scripts
git commit -m "Initial Raspberry Pi Modbus simulator setup"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

Then, on the Pi:

```sh
mkdir -p ~/projects
cd ~/projects
git clone <your-repo-url> Raspi_ModbusTCP_Slaves_Simulator
cd Raspi_ModbusTCP_Slaves_Simulator
```

Option B: copy the files manually from your Mac to the Pi:

```sh
ssh pi@modbus-sim.local "mkdir -p ~/projects/Raspi_ModbusTCP_Slaves_Simulator"
scp -r README.md docs scripts pi@modbus-sim.local:~/projects/Raspi_ModbusTCP_Slaves_Simulator/
```

Either way, the project should end up at:

```sh
~/projects/Raspi_ModbusTCP_Slaves_Simulator
```

## 8. Run Preflight Check

From the project directory:

```sh
bash scripts/pi-preflight.sh
```

The script checks the basics we need before building the simulator service.

## 9. Run Bootstrap

From the project directory:

```sh
bash scripts/pi-bootstrap.sh
```

This installs the base Linux packages we need and creates a local Python virtual environment at:

```sh
~/projects/Raspi_ModbusTCP_Slaves_Simulator/.venv
```

## 10. Ethernet For Modbus Simulation

Wi-Fi is fine for setup and file copying, but the 128-slave simulator should use Ethernet.

The reason is that each simulated slave needs a unique virtual MAC address. Normal Wi-Fi client mode usually does not carry many different source MAC addresses cleanly from one client device.

Before enabling simulated slaves, plug in Ethernet and verify:

```sh
nmcli device status
ip -brief addr show eth0
```

For this project, configure the Pi Ethernet address as:

```text
185.180.180.100/24
```

Reserve a separate range for simulated slaves, for example:

```text
185.180.180.101 - 185.180.180.228
```

Keep this as an isolated Modbus/lab network unless you own and route this address space. Do not use Ethernet as the default internet route for this setup.

From the project directory on the Pi, configure `eth0`:

```sh
bash scripts/configure-eth0-modbus.sh
```

This creates a NetworkManager connection named `eth0-modbus`, assigns `185.180.180.100/24`, and prevents Ethernet from stealing the default route from Wi-Fi.

## 11. Next Step

After the Pi is prepared, the next project step is the network model:

- Use Linux `macvlan` interfaces for simulated slaves.
- Generate one unique MAC address and IP address per slave.
- Bind one Modbus TCP server instance per slave IP on TCP port `502`.
- Keep the management web GUI on a separate port, probably `8080`.

## 12. Create Two Test Slave Interfaces

After `eth0` is configured as `185.180.180.100/24`, create two test slave interfaces:

```sh
cd ~/projects/Raspi_ModbusTCP_Slaves_Simulator
bash scripts/create-macvlan-slaves.sh 2
```

Expected interfaces:

```text
mbslave1  185.180.180.101/24  02:54:4d:33:00:01
mbslave2  185.180.180.102/24  02:54:4d:33:00:02
```

Verify them:

```sh
bash scripts/verify-macvlan-slaves.sh 2
```

List active slave interfaces:

```sh
bash scripts/list-macvlan-slaves.sh
```

Delete them if you need to reset:

```sh
bash scripts/delete-macvlan-slaves.sh 2
```


## 13. Run Two Test Modbus TCP Servers

Install Python requirements if you have not done it after copying `requirements.txt`:

```sh
bash scripts/pi-bootstrap.sh
```

Start two Modbus TCP servers:

```sh
bash scripts/run-modbus-slaves.sh 2
```

Verify holding register reads:

```sh
bash scripts/verify-modbus-slaves.sh
```

Expected result:

```text
OK   185.180.180.101:502: holding registers 0-4 = [1, 185, 180, 180, 101]
OK   185.180.180.102:502: holding registers 0-4 = [2, 185, 180, 180, 102]
```

Stop the servers:

```sh
bash scripts/stop-modbus-slaves.sh 2
```

## 14. GUI Features

The web GUI supports:

- Exporting and importing `config/slaves.json`.
- Editing each slave's enabled state, name, profile, IP address, and MAC address.
- Editing live coils/registers for each slave.
- `Apply & Restart Simulator`, which saves the running network/server state from the current config.
- Service status for the web GUI and simulator services.
- Per-slave status from the simulator manager, including interface state and TCP port state.

Service checks from the Pi:

```sh
bash scripts/service-status.sh
```

Scale checks from the Pi:

```sh
bash scripts/scale-test.sh
```
