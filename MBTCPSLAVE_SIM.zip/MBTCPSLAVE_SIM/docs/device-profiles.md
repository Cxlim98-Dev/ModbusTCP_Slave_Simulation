# Device Profiles

The simulator will support selectable device profiles. A profile controls which protocol behavior, register map, and identity data each simulated slave exposes.

Initial profiles:

- `generic-modbus-tcp`
- `schneider-tm3bceip`

## Generic Modbus TCP

This profile is for normal Modbus TCP testing where the master only needs a configurable slave/server.

Expected behavior:

- Configurable IP address.
- Configurable MAC address through the virtual network interface.
- TCP port `502`.
- Holding registers.
- Input registers.
- Coils.
- Discrete inputs.
- Configurable register ranges and default values.
- Common Modbus function codes:
  - `01` read coils.
  - `02` read discrete inputs.
  - `03` read holding registers.
  - `04` read input registers.
  - `05` write single coil.
  - `06` write single holding register.
  - `15` write multiple coils.
  - `16` write multiple holding registers.

## Schneider TM3BCEIP

This profile aims to behave like the Modbus TCP side of a Schneider Electric Modicon TM3BCEIP Ethernet bus coupler.

Scope for first implementation:

- Simulate the Modbus TCP server behavior.
- Expose TM3BCEIP-like device identification through function code `43/14`.
- Expose TM3-style diagnostic and status holding registers.
- Expose configurable I/O module data ranges.
- Let the GUI choose this profile per simulated slave.

Out of scope for first implementation:

- Full EtherNet/IP adapter behavior.
- Exact EcoStruxure Machine Expert discovery behavior.
- Firmware update, FDR, web server clone, USB behavior, or hardware LED behavior.
- Safety-certified or production replacement behavior.

Known Schneider TM3BCEIP Modbus TCP behavior from Schneider documentation:

- Communication type: EtherNet/IP and Modbus TCP.
- Ethernet: two isolated switched Ethernet ports on the real device.
- Modbus TCP server supports:
  - `03` read holding registers.
  - `06` write single register.
  - `16` write multiple registers.
  - `22` mask write register.
  - `23` read/write multiple registers.
  - `43/14` read device identification.
- TM3 bus coupler Modbus TCP registers include diagnostic and status areas around registers `900`, `930`, and `932`.

Current simulator preset:

- Modbus device identity:
  - Vendor name: `Schneider Electric`
  - Product code: `TM3BCEIP`
  - Product name: `Modicon TM3 Ethernet Bus Coupler`
  - Model name: `TM3BCEIP`
- Holding register `0`: simulator slave index.
- Holding registers `1` to `4`: slave IP address octets.
- Holding register `900`: diagnostic placeholder.
- Holding register `901`: simulator slave index.
- Holding register `902`: configured TM3 module count.
- Holding register `930`: bus/status placeholder, `1`.
- Holding register `932`: Modbus TCP IO scanner control placeholder, `5`.
- Holding registers `940` to `943`: module code placeholders for slots 1 to 4.
- Discrete inputs `0` to `15`: `TM3DI16` input image.
- Coils `0` to `15`: `TM3DQ16` output image.
- Input registers `0` to `3`: `TM3AI4` analog input image.
- Holding registers `100` to `103`: `TM3AQ4` analog output image.

Implementation note: on the Raspberry Pi we cannot reproduce the physical two-port switched hardware, but we can reproduce the network-visible Modbus TCP behavior well enough for master software testing.

## GUI Selection

The web GUI should expose a profile selector when creating or editing each simulated slave:

- `Generic Modbus TCP`
- `Schneider TM3BCEIP`

Suggested per-slave configuration fields:

- Enabled.
- Name.
- Profile.
- IP address.
- MAC address.
- Unit ID behavior.
- Register preset.
- TM3 module layout when using `Schneider TM3BCEIP`.

Default TM3BCEIP module layout:

- Slot 1: `TM3DI16`
- Slot 2: `TM3DQ16`
- Slot 3: `TM3AI4`
- Slot 4: `TM3AQ4`

In the GUI, the TM3 Modules field is only enabled when the profile is `schneider-tm3bceip`.
Leaving the field empty means no expansion modules are attached.

## Suggested Internal Model

Each simulated slave can be represented by a config object:

```json
{
  "enabled": true,
  "name": "TM3BCEIP-001",
  "profile": "schneider-tm3bceip",
  "ip_address": "192.168.10.101",
  "mac_address": "02:54:4d:33:00:01",
  "tcp_port": 502,
  "unit_id": 255,
  "register_preset": "tm3bceip-default",
  "tm3_modules": []
}
```

Use locally administered MAC addresses. The first octet should have bit 1 set, for example `02:...`.

## References

- Schneider Electric Machine Expert documentation, TM3BCEIP Modbus TCP server.
- Schneider Electric Machine Expert documentation, TM3 bus coupler hardware description.
