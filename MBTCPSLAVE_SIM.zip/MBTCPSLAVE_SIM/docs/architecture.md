# Project Architecture

This project turns a Raspberry Pi into a configurable Modbus TCP slave simulator.

## High-Level Architecture

```mermaid
flowchart LR
    User["User Browser"] -->|HTTP :8080| Web["Web GUI<br/>modbus-sim-web.service"]
    Web --> Config["config/slaves.json"]
    Web --> Values["run/slave-N-values.json"]
    Web -->|start / stop / restart / status| Manager["Simulator Manager<br/>simulator.manage"]

    Manager -->|creates| Macvlan["macvlan interfaces<br/>mbslave1..mbslave128"]
    Manager -->|starts| Servers["Modbus TCP Servers<br/>one process per slave"]

    Config --> Manager
    Values --> Servers

    Servers -->|bind :502| IPs["Slave IPs<br/>185.180.180.101+"]
    PC["PLC / HMI / Modbus Client"] -->|Modbus TCP :502| IPs

    PiWifi["Pi Wi-Fi<br/>SSH / GUI / Internet"] --> Web
    PiEth["Pi eth0<br/>185.180.180.100/24"] --> Macvlan
```

## Network Layout

```text
Wi-Fi / wlan0
  Purpose: SSH, web GUI, internet, package installation
  Example: 192.168.0.146

Ethernet / eth0
  Purpose: isolated Modbus simulation network
  Pi IP:   185.180.180.100

Virtual slave interfaces / macvlan
  mbslave1: 185.180.180.101, unique MAC
  mbslave2: 185.180.180.102, unique MAC
  ...
  mbslave128: 185.180.180.228, unique MAC
```

## Runtime Components

```mermaid
flowchart TB
    Systemd["systemd"] --> WebSvc["modbus-sim-web.service"]
    Systemd --> SimSvc["modbus-slave-simulator.service"]

    WebSvc --> Flask["Flask Web GUI<br/>simulator.web"]
    SimSvc --> Manager["simulator.manage"]

    Flask --> SlaveConfig["Slave Config<br/>config/slaves.json"]
    Flask --> LiveEditor["Live Values Editor"]
    Flask --> Actions["Apply / Restart / Stop"]

    Manager --> Interfaces["Create macvlan interfaces"]
    Manager --> Processes["Start Modbus server processes"]

    Processes --> Server1["Server 1<br/>185.180.180.101:502"]
    Processes --> Server2["Server 2<br/>185.180.180.102:502"]
    Processes --> ServerN["Server N<br/>185.180.180.N:502"]

    LiveEditor --> ValueFiles["run/slave-N-values.json"]
    ValueFiles --> Server1
    ValueFiles --> Server2
    ValueFiles --> ServerN
```

## Profiles

```text
generic-modbus-tcp
  General Modbus TCP slave behavior.
  TM3 Modules field is disabled.

schneider-tm3bceip
  Schneider TM3BCEIP-like profile.
  Supports Schneider identity metadata and TM3 module layout fields.
  TM3 Modules field is enabled.
```

## Important Files

```text
config/slaves.json
  Main simulator configuration.

simulator/web.py
  Web GUI.

simulator/manage.py
  Creates interfaces, starts/stops servers, prints status.

simulator/modbus_server.py
  One Modbus TCP server process.

simulator/live_values.py
  File-backed coils/registers for live value editing.

scripts/configure-eth0-modbus.sh
  Configures eth0 as 185.180.180.100/24 with no default gateway.

scripts/install-web-systemd-service.sh
  Installs the web GUI service.

scripts/install-systemd-service.sh
  Installs the simulator service.
```

