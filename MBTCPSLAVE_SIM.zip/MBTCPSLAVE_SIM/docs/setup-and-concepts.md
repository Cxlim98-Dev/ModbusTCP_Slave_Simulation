# Setup And Concepts

This document explains how the Raspberry Pi Modbus TCP slave simulator was set up and the main concepts behind it.

## Purpose

The goal is to simulate many Modbus TCP slaves from one Raspberry Pi.

Requirements:

- Up to 128 Modbus TCP slaves.
- Each slave has a unique IP address.
- Each slave has a unique MAC address.
- User can configure slaves from a web GUI.
- User can choose generic Modbus TCP or Schneider TM3BCEIP-like behavior.

## Raspberry Pi Network Design

The Pi uses two logical networks:

```text
wlan0 / Wi-Fi
  SSH, web GUI, internet access

eth0 / Ethernet
  Modbus TCP simulation network
```

This separation is important because the simulator needs many virtual MAC addresses. Normal Wi-Fi client mode does not reliably support many source MAC addresses behind one Wi-Fi client, so the simulated slaves are placed on wired Ethernet.

## eth0 Configuration

The Pi Ethernet interface is configured as:

```text
185.180.180.100/24
```

It has no default gateway. This prevents Ethernet from stealing internet routing away from Wi-Fi.

The script that applies this is:

```sh
scripts/configure-eth0-modbus.sh
```

It creates a NetworkManager connection named:

```text
eth0-modbus
```

## macvlan Interfaces

Linux `macvlan` lets one physical Ethernet interface expose many virtual Ethernet interfaces.

The simulator uses this to create:

```text
mbslave1
mbslave2
...
mbslave128
```

Each virtual interface has:

- Unique interface name.
- Unique IP address.
- Unique MAC address.

Example:

```text
mbslave1  185.180.180.101/24  02:54:4d:33:00:01
mbslave2  185.180.180.102/24  02:54:4d:33:00:02
```

## Modbus Server Model

Each enabled slave gets one Modbus TCP server process.

Example:

```text
185.180.180.101:502
185.180.180.102:502
185.180.180.103:502
```

This means a Modbus client sees separate devices at separate IP addresses, even though they all run on the same Raspberry Pi.

## Configuration Model

The main config file is:

```text
config/slaves.json
```

It contains global defaults and per-slave configuration.

Example fields:

```json
{
  "parent_interface": "eth0",
  "base_ip_prefix": "185.180.180",
  "start_host": 101,
  "cidr_prefix": 24,
  "tcp_port": 502,
  "slave_count": 2,
  "profile": "generic-modbus-tcp",
  "slaves": []
}
```

Each slave can define:

```text
enabled
name
profile
ip_address
mac_address
tm3_modules
```

## CIDR Prefix

CIDR prefix controls subnet size.

Example:

```text
185.180.180.101/24
```

`/24` means subnet mask:

```text
255.255.255.0
```

The code allows CIDR prefixes from `1` to `32`, including `/8`.

## Profiles

### Generic Modbus TCP

Generic profile is for normal Modbus TCP testing.

It supports basic coils and registers without Schneider-specific module layout.

The TM3 Modules field is disabled for this profile.

### Schneider TM3BCEIP

TM3BCEIP profile is for Schneider EcoStruxure Machine Expert Basic style testing.

It adds:

- Schneider-like Modbus device identity.
- TM3BCEIP product/model strings.
- TM3 module layout field.
- Placeholder TM3 status/register values.
- I/O image mapping for supported TM3 module names.

Supported module names:

```text
TM3DI16
TM3DQ16
TM3AI4
TM3AQ4
```

Assumed layout:

```text
Slot 1: TM3DI16
Slot 2: TM3DQ16
Slot 3: TM3AI4
Slot 4: TM3AQ4
```

An empty TM3 Modules field means no expansion modules.

## TM3 I/O Mapping

For the current TM3 preset:

```text
TM3DI16 -> discrete inputs 0-15
TM3DQ16 -> coils 0-15
TM3AI4  -> input registers 0-3
TM3AQ4  -> holding registers 100-103
```

Additional TM3BCEIP placeholder registers:

```text
Holding register 900      diagnostic placeholder
Holding register 901      simulator slave index
Holding register 902      TM3 module count
Holding register 930      bus/status placeholder
Holding register 932      Modbus TCP IO scanner control placeholder
Holding registers 940-943 module code placeholders
```

This is not a full hardware clone. It is a practical Modbus-visible approximation that can be refined against EcoStruxure Machine Expert Basic behavior.

## Live Values

Live values are stored in JSON files under:

```text
run/slave-N-values.json
```

The Modbus server uses file-backed data blocks. This allows the GUI to update coils/registers while the server is running.

The GUI currently exposes:

```text
Coils 0-15
Discrete Inputs 0-15
Holding Registers 0-20
Input Registers 0-20
```

## systemd Services

Two services are used.

```text
modbus-sim-web.service
```

Runs the Flask web GUI on port `8080`.

```text
modbus-slave-simulator.service
```

Creates macvlan interfaces and starts the Modbus TCP server processes.

## Setup Scripts

Important scripts:

```text
scripts/pi-preflight.sh
  Shows OS, network, Python, and listening ports.

scripts/pi-bootstrap.sh
  Installs packages and Python dependencies.

scripts/configure-eth0-modbus.sh
  Configures eth0 for the Modbus network.

scripts/install-web-systemd-service.sh
  Installs the web GUI service.

scripts/install-systemd-service.sh
  Installs the simulator service.

scripts/service-status.sh
  Shows service and simulator status.

scripts/scale-test.sh
  Shows interface count, listeners, and process summary.
```

## Typical Startup Flow

On boot:

```mermaid
sequenceDiagram
    participant systemd
    participant web as Web GUI Service
    participant sim as Simulator Service
    participant manager as simulator.manage
    participant net as macvlan interfaces
    participant mb as Modbus servers

    systemd->>web: start modbus-sim-web.service
    systemd->>sim: start modbus-slave-simulator.service
    sim->>manager: manage start
    manager->>net: create mbslave interfaces
    manager->>mb: start server per enabled slave
```

## Operational Notes

- Use Wi-Fi IP for GUI and SSH.
- Use Ethernet IP range for Modbus clients.
- Keep `eth0` without a default gateway unless it is intentionally routed.
- After config changes, click `Apply & Restart Simulator`.
- Live value changes normally do not need a restart.
- For 128 slaves, test gradually: 8, 16, 32, then 128.

