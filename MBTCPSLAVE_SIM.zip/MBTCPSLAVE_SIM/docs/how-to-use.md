# How To Use

This is the daily operating procedure for the Raspberry Pi Modbus TCP slave simulator.

## 1. Power On

Power on the Raspberry Pi and wait about one minute.

The Pi should start:

- Web GUI service.
- Modbus simulator service.
- Configured virtual slave interfaces.
- Configured Modbus TCP servers.

## 2. Open The GUI

From a browser on the admin network, open:

```text
http://192.168.0.146:8080
```

If hostname resolution is working, this may also work:

```text
http://modbus-sim.local:8080
```

Use the Pi Wi-Fi/admin IP for the GUI. Do not use the `185.180.180.x` Modbus test network unless your PC is connected to that network.

## 3. Configure Slaves

In the GUI, edit:

- Slave count.
- Parent interface, normally `eth0`.
- TCP port, normally `502`.
- CIDR prefix, commonly `24`.
- Per-slave enabled state.
- Per-slave name.
- Per-slave profile.
- Per-slave IP address.
- Per-slave MAC address.

For generic devices, use:

```text
generic-modbus-tcp
```

For Schneider-style bus couplers, use:

```text
schneider-tm3bceip
```

## 4. Configure TM3 Modules

The TM3 Modules field is only available when the profile is:

```text
schneider-tm3bceip
```

Example module list:

```text
TM3DI16,TM3DQ16,TM3AI4,TM3AQ4
```

Leaving the field empty means no expansion modules are attached.

## 5. Apply Changes

After changing configuration, click:

```text
Apply & Restart Simulator
```

This recreates the virtual slave interfaces and restarts the Modbus server processes.

## 6. Edit Live Values

In the GUI, click `Values` on a slave row.

You can edit:

- Coils `0-15`.
- Discrete inputs `0-15`.
- Holding registers `0-20`.
- Input registers `0-20`.

Click:

```text
Save Live Values
```

The running Modbus server reads these file-backed values, so most value changes do not require a simulator restart.

Use:

```text
Refresh Values
```

to reload values that may have been written by a Modbus client.

Use:

```text
Reset Defaults
```

to regenerate default values for that slave.

## 7. Test From A Modbus Client

Connect the client PC to the Raspberry Pi Ethernet/Modbus network.

Example slave IPs:

```text
185.180.180.101
185.180.180.102
185.180.180.103
```

Use TCP port:

```text
502
```

Read holding registers, coils, discrete inputs, or input registers from the selected slave IP.

## 8. Check Status From SSH

SSH into the Pi:

```sh
ssh pi@192.168.0.146
```

Then run:

```sh
cd ~/projects/Raspi_ModbusTCP_Slaves_Simulator
bash scripts/service-status.sh
bash scripts/scale-test.sh
```

Check virtual slave interfaces:

```sh
ip -brief addr show | grep mbslave
```

Check Modbus TCP listeners:

```sh
ss -ltnp | grep ':502'
```

## 9. Restart Services

Restart the web GUI:

```sh
sudo systemctl restart modbus-sim-web.service
```

Restart the simulator:

```sh
sudo systemctl restart modbus-slave-simulator.service
```

Check status:

```sh
systemctl status modbus-sim-web.service --no-pager -l
systemctl status modbus-slave-simulator.service --no-pager -l
```

## 10. Backup Configuration

In the GUI:

```text
Export Config
```

This downloads the current `slaves.json`.

To restore a config:

```text
Import Config
Apply & Restart Simulator
```

