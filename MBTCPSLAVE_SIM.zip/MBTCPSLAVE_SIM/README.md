# Raspberry Pi Modbus TCP Slaves Simulator

This project will turn a Raspberry Pi into a configurable Modbus TCP slave simulator.

Planned capabilities:

- Simulate up to 128 Modbus TCP slaves.
- Let users configure how many slaves are active.
- Give each simulated slave its own IP address and MAC address.
- Provide a local web GUI for configuration.

Start here:

- [Raspberry Pi setup guide](docs/raspi-setup.md)

Manual simulator commands on the Raspberry Pi:

```sh
cd ~/projects/Raspi_ModbusTCP_Slaves_Simulator
bash scripts/simulator-start.sh
bash scripts/simulator-status.sh
bash scripts/verify-modbus-slaves.sh
bash scripts/simulator-stop.sh
```

Service and scale checks:

```sh
bash scripts/service-status.sh
bash scripts/scale-test.sh
```

Web GUI:

```sh
bash scripts/web-start.sh
```

Then open:

```text
http://modbus-sim.local:8080
```

Live values:

- Open the GUI.
- Click `Values` on a slave row.
- Edit coils, discrete inputs, holding registers, or input registers.
- Click `Save Live Values`.

The running Modbus server reads these values from disk, so most value changes do not require restarting the simulator.
